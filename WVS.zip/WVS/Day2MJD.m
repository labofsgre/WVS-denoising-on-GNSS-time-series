function MJD_Time = Day2MJD(time)
    MJD_Time = 51544 + (time-2000)*365.2 ;
end