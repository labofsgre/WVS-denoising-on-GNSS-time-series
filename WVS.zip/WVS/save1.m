function   save1(DATA,ss)
%SAVE 此处显示有关此函数的摘要
%   此处显示详细说明
save([A(ss).name(1:6)  '.mat'],'DATA') 
end

